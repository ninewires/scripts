#!/bin/bash

# Tool to lookup RIR governing an IP address
#
# Usage: <script_name> <ip_file>
#
# Script writes to file 'rirlist.txt' in the current working directory
#
# Author: Jason Ashton
# Created: 04/07/2017

outfile="rirlist.txt"
inputfile=$1
rirfile="ipv4-address-space.csv"

# Argument Check & Usage
sname=$(basename "$0")

if [ $# -ne 1 ]; then
	echo
	echo "Usage: $sname <source_file>"
	echo
	exit 1
fi

# Input Validation
GRN='\x1B[1;32m'
WHT='\x1B[1;37m'
RED='\x1B[1;31m'
YEL='\x1B[1;33m'
NC='\x1B[0m'

CNT=0

while read ipaddr; do
	addr=( $(echo $ipaddr | tr \. " " | tr \- " " | tr \/ " ") )
	if [[ ${#addr[@]} -le 4 ]]; then
		if ! [[ $ipaddr =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
			echo
			echo -e "In ${YEL}$inputfile ${WHT}[$ipaddr]${NC} Is Not a Valid IP Address" >&2
			let CNT++;
		elif [[ (${addr[0]} -eq 0 || ${addr[0]} -gt 255) || ${addr[1]} -gt 255 || ${addr[2]} -gt 255 || ${addr[3]} -gt 255 ]]; then
			echo
			echo -e "In ${YEL}$inputfile ${WHT}[$ipaddr]${NC} Is Not a Valid IP Address" >&2
			let CNT++;
		fi
	fi
done < $inputfile

# Check for Errors & Exit
if [[ $CNT -gt 0 ]]; then
	echo
	echo -e "${RED}Oops, fix these errors & try again${NC}"
	echo
	exit 1
fi

# Look-up RIRs
echo "IP Address,RIR" > tmpout
while read ipaddr; do
	prefix=$(echo $ipaddr | cut -d'.' -f1)
	iprir=$(grep -m1 "$prefix" $rirfile | cut -d',' -f2)
	echo "$ipaddr,$iprir" >> tmpout
done < $inputfile

# Create output file
cat tmpout | column -s',' -t >> $outfile
rm tmpout 2>/dev/null	