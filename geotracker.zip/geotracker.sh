#!/bin/bash

# not the jeep wannabe from the 80s/90s
# a script for looking an IP address geo location
#
# Auther: Jason Ashton (@ninewires)
# Created: 01/07/2017


cat << "banner"


			     `+######;
			     #@@@@@###;  `;;;;;;,   `;;;;;:
			    ;@+         #@@@@@@@@# ;@@@@@@@@`
			    @@         ,@#      @@ @@.  ` `@@
			    @#   @@@@@'@@ @@@@@@@@+@ ,:,,+:,@`
			    @@   ####@;@@ @@@@@@# +@ .,..'.`@.
			    +@:      @;'@,        .@'';.`.'@@
			     @@@#####@; @@@######+ @@@####@@'
			      ;@@@@@@@'  +@@@@@@@+  '@@@@@#,


           `,'##@@@@@@@@@@#`       `@       .+@@#     #'         `..,,::;',  ;#####'.
   ,+@@@@@@@@@@@@@@@@@@@@@@@,    .@@@    +@@@@@@@    @@@@   `#@ @@@@@@@@@@@ '@@@@@@@@@:
 @@@@@@@@@@@@@@@@@@@@+''@@@@@  `@@@@@: @@@@@@@@@@  `@@@@` #@@@@@@@@@@@@@@@@;@@@@@@@@@@@
  @@@@@@@@@@@#  @@@@  #@@@@@+`@@@@@@@@@@@@@@@@@@@:.@@@@+@@@@@@@@@@@':..`` ,@@@@    +@@@+
   @@'. @@@@@  @@@@#@@@@@@, @@@@@@#@@@@@@@@#.    ,@@@@@@@@@@;.@@@@@@@@@@; @@@@` `#@@@@@@
       +@@@@  @@@@@@@@@@@'+@@@@@' .@@@@@@`      :@@@@@@@@:   @@@@@@@@@@@ @@@@@@@@@@@@@'
      .@@@@  ;@@@@@@@@@@@@@@@@@+.  @@@@@`      :@@@@@@@@@@@;@@@@@++'';' @@@@@@@@@@@+
      @@@@.  @@@@  `,+@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@######@@@@@@@@@@@@@@@:
     @@@@+  @@@@.     @@@@@+@@@@@@@@@@+@@@@@@@@@@@@   .#@@@@@@@@@@@@@@@@@@@``;@@@@@@@@@@@#,
     @@@@    @@#      #@@@      :@@@@@#.@@@@@@@@@@`       +@@@@@@@@@@@@@@@@      ,@@@@@@@@@@+
     `@@      @        @#           .+@  +@@+:` .+          `#@+.```     @           :@@@@@+


A tool for performing geo location lookups on IP addresses (not the fake Jeep)

banner

GRN='\x1B[1;32m'
WHT='\x1B[1;37m'
RED='\x1B[1;31m'
YEL='\x1B[1;33m'
NC='\x1B[0m'

starttpath=$(pwd)
TIME=$(date +"%m%d%Y-%H%M%S")
outputpath="geoip-${TIME}"
filename="geoip.htm"
csvfilename="geoip.csv"
kmlfilename="geoip.kml"
geodata="geodata.htm"
countries="resource/country-codes.csv"
flagspath="../resource/flags/"

# Catch termination
trap f_term SIGHUP SIGINT SIGTERM

f_term()
{
	echo
	echo
	echo -e "${WHT}Caught ${RED}ctrl+c${NC} . . ."
	echo -e "${WHT}Cleaning up my mess. . . ${NC}"
	cd $starttpath
	if [ -d $outputpath ]; then
		rm -rf $outputpath
	fi
	exit
}

# Selection error
f_error()
{
	echo
	echo -e "${RED}Invalid Option, try again. . .${NC}"
}

# Error Check Function
f_err_check()
{
	if [[ $CNT -gt 0 ]]; then
		echo
		echo -e "${RED}Oops, fix & try again${NC}"
		echo
		f_menu
	fi
}

# Input Format Check Function
f_valid_ipaddr()
{
	# Valid IP address Check
	addr=( $(echo $ipaddr | tr \. " ") )

	if ! [[ $ipaddr =~ [0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3} ]]; then
		echo
		echo -e "${WHT}$ipaddr${NC} Is Not a Valid IP Address" >&2
		let CNT++;
	elif [[ (${addr[0]} -eq 0 || ${addr[0]} -gt 255) || ${addr[1]} -gt 255 || ${addr[2]} -gt 255 || ${addr[3]} -gt 255 ]]; then
		echo
		echo -e "${WHT}$ipaddr${NC} Is Not a Valid IP Address" >&2
		let CNT++;
	fi
}

# Input From single IP Function
f_ipinput()
{
	CNT=0
	echo
	echo -n -e "${WHT}Enter IP address:${NC} " 
	read ipaddr
	
	# Valid IP Address Check
	f_valid_ipaddr
	f_err_check

	# geo location lookup
	echo
	echo -e "${WHT}IP Address Geo Location:${NC}"
	f_geolookup | sed 's|,|\n|g' | sed 's/\("\|{\|}\)//g' > tmpgeo
	geoip=$(grep -m1 'ip:' tmpgeo | cut -d':' -f2)
	geoccode=$(grep 'country_code:' tmpgeo | cut -d':' -f2)
	geocountry=$(grep 'country_name:' tmpgeo | cut -d':' -f2)
	geocity=$(grep 'city:' tmpgeo | cut -d':' -f2)
	georegion=$(grep 'region_name:' tmpgeo | cut -d':' -f2)
	geolat=$(grep 'latitude:' tmpgeo | cut -d':' -f2)
	geolong=$(grep 'longitude:' tmpgeo | cut -d':' -f2)
	echo -e "IP Address: $geoip"
	echo -e "Country: $geocountry"
	echo -e "Country Code: $geoccode"
	echo -e "State/Region: $georegion"
	echo -e "City: $geocity"
	echo -e "Latitude: $geolat"
	echo -e "Longitude: $geolong"
	rm tmpgeo 2>/dev/null
	echo
	exit
}

# IP lookup Function
f_geolookup()
{
	# old sources:
	# curl --silent http://api.hackertarget.com/geoip/?q=$ipaddr
	# curl --silent http://www.freegeoip.net/csv/${ipaddr}
	curl --silent http://api.ipstack.com/${ipaddr}?access_key=de1a16700afa36d2536bdb8e4e78d65a
}

# Input From File Function
f_fileinput()
{
	CNT=0
	echo
	echo -n -e "${WHT}Enter path to input file:${NC} " 
	read -e inputfile

	# Input file check
	while [ ! -f $inputfile ]; do
		echo
		echo -e "${WHT}$inputfile ${RED}Not Found!${NC}"
		echo
		echo -n -e "${WHT}Enter path to input file:${NC} " 
		read -e inputfile
	done

	# File type check
	if file $inputfile | grep 'with CRLF line terminators' 1>/dev/null; then
		echo -e "eeeeew ${WHT}$inputfile ${NC}is a windoze format"
		echo -e "Get ${WHT}$inputfile ${NC}converted with dos2unix and try again."
		exit
	fi

	# Valid IP address check
	while read ipaddr; do
		f_valid_ipaddr
	done < $inputfile
	f_err_check

	# Output path creation
	mkdir $outputpath
	cd $outputpath

	# Geo location lookup
	totalip=$(wc -l ../$inputfile | cut -d' ' -f1)
	# Create file for HTML output
	echo "IP Address,Country,CC,State/Region,City,Latitude,Longitude,Flag" > tmpfile
	# Create file for CSV output
	echo "IP Address,Country,CC,State/Region,City,Latitude,Longitude" > $csvfilename
	# Create file for KML output
	echo '<?xml version="1.0" encoding="UTF-8"?>' > $kmlfilename
	echo '<kml xmlns="http://earth.google.com/kml/2.2">' >> $kmlfilename
	echo "  <Document>" >> $kmlfilename
	echo "    <name>geoip KML output</name>" >> $kmlfilename
	echo "      <Style><PolyStyle><fill>0</fill><outline>1</outline></PolyStyle></Style>" >> $kmlfilename
	while read ipaddr; do
		f_geolookup | sed 's|,|\n|g' | sed 's/\("\|{\|}\)//g' > tmpgeo
		geoip=$(grep -m1 'ip:' tmpgeo | cut -d':' -f2)
		geoccode=$(grep 'country_code:' tmpgeo | cut -d':' -f2)
		geocountry=$(grep 'country_name:' tmpgeo | cut -d':' -f2)
		geocity=$(grep 'city:' tmpgeo | cut -d':' -f2)
		georegion=$(grep 'region_name:' tmpgeo | cut -d':' -f2)
		geolat=$(grep 'latitude:' tmpgeo | cut -d':' -f2)
		geolong=$(grep 'longitude:' tmpgeo | cut -d':' -f2)
		geocclower=$(echo $geoccode | sed -e 's|\(.*\)|\L\1|')
		geoflag="flags/${geocclower}.png"
		geoflaghtml="<img src="$geoflag">"
		echo "$geoip,$geocountry,$geoccode,$geocity,$georegion,$geolat,$geolong,$geoflaghtml" >> tmpfile
		echo "$geoip,$geocountry,$geoccode,$geocity,$georegion,$geolat,$geolong" >> $csvfilename
		echo "        <Placemark><name>${geoip}</name><MultiGeometry><Point><coordinates>${geolong},${geolat}</coordinates></Point></MultiGeometry></Placemark>" >> $kmlfilename
		let number=number+1
		echo
		echo -e -n "\t**** $number of $totalip ****"
		printf "\33[A"
	done < ../$inputfile

	# Close KML file
	echo "  </Document>" >> $kmlfilename
	echo "</kml>" >> $kmlfilename

	# Build geodata.htm file
	cp ../resource/$geodata .
	cat tmpfile | column -n -s',' -t >> $geodata
	echo '</pre>' >> $geodata

	# Create htm file
	cp ../resource/geo.htm $filename
	cp -R $flagspath .
	rm tmpgeo tmpfile 2>/dev/null
	cd ..
	echo
	echo -e "Three output files for your use located in ${WHT}${outputpath}${NC}:"
	echo -e "\t${RED}$filename ${WHT} lookup results for view in a web browser, including country flags.${NC}"
	echo -e "\t${RED}$csvfilename ${WHT} for further parsing/sorting.${NC}"
	echo -e "\t${RED}$kmlfilename ${WHT} for view in Google Earth. All pins marked by IP Address.${NC}"
	exit
}

# Menu Function	
f_menu()
{
	echo
	echo -e "${WHT}Please Select:${NC}"
	echo
	echo "1. Input single IP Address"
	echo "2. Input From File"
	echo "0. Quit"
	echo
	read -p "Enter Selection: "

	while [[ $REPLY != "0" ]] && [[ $REPLY != "1" ]] && [[ $REPLY != "2" ]]; do
		echo
		read -p "Nope. Your only options are [0-2] > "
	done

	if [[ $REPLY =~ ^[0-2]$ ]]; then
		if [[ $REPLY == 0 ]]; then
			echo
			echo "Later brofessor :-)"
			echo
			exit
		fi
		if [[ $REPLY == 1 ]]; then
			f_ipinput
		fi
		if [[ $REPLY == 2 ]]; then
			f_fileinput
		fi
	fi
	return
}

f_menu