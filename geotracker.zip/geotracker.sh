#!/bin/bash

# not the jeep wannabe from the 80s/90s
# a script for looking an IP address geo location
#
# Auther: Jason Ashton (@ninewires)
# Created: 01/07/2017


cat << "banner"


			     `+######;
			     #@@@@@###;  `;;;;;;,   `;;;;;:
			    ;@+         #@@@@@@@@# ;@@@@@@@@`
			    @@         ,@#      @@ @@.  ` `@@
			    @#   @@@@@'@@ @@@@@@@@+@ ,:,,+:,@`
			    @@   ####@;@@ @@@@@@# +@ .,..'.`@.
			    +@:      @;'@,        .@'';.`.'@@
			     @@@#####@; @@@######+ @@@####@@'
			      ;@@@@@@@'  +@@@@@@@+  '@@@@@#,


           `,'##@@@@@@@@@@#`       `@       .+@@#     #'         `..,,::;',  ;#####'.
   ,+@@@@@@@@@@@@@@@@@@@@@@@,    .@@@    +@@@@@@@    @@@@   `#@ @@@@@@@@@@@ '@@@@@@@@@:
 @@@@@@@@@@@@@@@@@@@@+''@@@@@  `@@@@@: @@@@@@@@@@  `@@@@` #@@@@@@@@@@@@@@@@;@@@@@@@@@@@
  @@@@@@@@@@@#  @@@@  #@@@@@+`@@@@@@@@@@@@@@@@@@@:.@@@@+@@@@@@@@@@@':..`` ,@@@@    +@@@+
   @@'. @@@@@  @@@@#@@@@@@, @@@@@@#@@@@@@@@#.    ,@@@@@@@@@@;.@@@@@@@@@@; @@@@` `#@@@@@@
       +@@@@  @@@@@@@@@@@'+@@@@@' .@@@@@@`      :@@@@@@@@:   @@@@@@@@@@@ @@@@@@@@@@@@@'
      .@@@@  ;@@@@@@@@@@@@@@@@@+.  @@@@@`      :@@@@@@@@@@@;@@@@@++'';' @@@@@@@@@@@+
      @@@@.  @@@@  `,+@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@######@@@@@@@@@@@@@@@:
     @@@@+  @@@@.     @@@@@+@@@@@@@@@@+@@@@@@@@@@@@   .#@@@@@@@@@@@@@@@@@@@``;@@@@@@@@@@@#,
     @@@@    @@#      #@@@      :@@@@@#.@@@@@@@@@@`       +@@@@@@@@@@@@@@@@      ,@@@@@@@@@@+
     `@@      @        @#           .+@  +@@+:` .+          `#@+.```     @           :@@@@@+


A Tool for performing geo location lookups on IP addresses

banner

GRN='\x1B[1;32m'
WHT='\x1B[1;37m'
RED='\x1B[1;31m'
YEL='\x1B[1;33m'
NC='\x1B[0m'

TIME=$(date +"%H%M%S")
filename="geoip-$TIME.htm"
geodata="geodata.htm"
countries="resource/country-codes.csv"
flagspath="/resource/"

# Catch termination
trap f_term SIGHUP SIGINT SIGTERM

f_term()
{
	echo
	echo
	echo -e "${WHT}Caught ${RED}ctrl+c${NC} . . . back to Main Menu"
	f_menu
}

# Selection error
f_error()
{
	echo
	echo -e "${RED}Inbalid Option, try again. . .${NC}"
}

# Error Check Function
f_err_check()
{
	if [[ $CNT -gt 0 ]]; then
		echo
		echo -e "${RED}Oops, fix & try again${NC}"
		echo
		f_menu
	fi
}

# Input Format Check Function
f_valid_ipaddr()
{
	# Valid IP address Check
	addr=( $(echo $ipaddr | tr \. " ") )

	if ! [[ $ipaddr =~ [0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3} ]]; then
		echo
		echo -e "${WHT}$ipaddr${NC} Is Not a Valid IP Address" >&2
		let CNT++;
	elif [[ (${addr[0]} -eq 0 || ${addr[0]} -gt 255) || ${addr[1]} -gt 255 || ${addr[2]} -gt 255 || ${addr[3]} -gt 255 ]]; then
		echo
		echo -e "${WHT}$ipaddr${NC} Is Not a Valid IP Address" >&2
		let CNT++;
	fi
}

# Input From single IP Function
f_ipinput()
{
	CNT=0
	echo
	echo -n -e "${WHT}Enter IP address:${NC} " 
	read ipaddr
	# Valid IP Address Check
	f_valid_ipaddr
	f_err_check

	# geo location lookup
	echo
	echo -e "${WHT}IP Address Geo Location:${NC}"
	f_geolookup
	echo
	echo
	f_menu
}

# List Gen Function
f_geolookup()
{
	echo
	curl --silent http://api.hackertarget.com/geoip/?q=$ipaddr
}

# Input From File Function
f_fileinput()
{
	CNT=0
	echo
	echo -n -e "${WHT}Enter path to input file:${NC} " 
	read -e inputfile
	while read ipaddr; do
		f_valid_ipaddr
	done < $inputfile
	f_err_check

	# geo location lookup
	echo "IP Address,Country,CC,State,City,Latitude,Longitude,Flag" > tmpfile
	while read ipaddr; do
		f_geolookup | sed 's|: |:|g' > tmpgeo
		geoip=$(grep 'Address' tmpgeo | cut -d':' -f2)
		geoccode=$(grep 'Country' tmpgeo | cut -d':' -f2)
		geocclower=$(echo $geoccode | sed -e 's|\(.*\)|\L\1|')
		geocity=$(grep 'City' tmpgeo | cut -d':' -f2)
		geostate=$(grep 'State' tmpgeo | cut -d':' -f2)
		geolat=$(grep 'Latitude' tmpgeo | cut -d':' -f2)
		geolong=$(grep 'Longitude' tmpgeo | cut -d':' -f2)
		geocountry=$(grep "$geoccode" $countries | cut -d',' -f1)
		geoflag="resource/${geocclower}.png"
		geoflaghtml="<img src="$geoflag">"
		echo "$geoip,$geocountry,$geoccode,$geocity,$geostate,$geolat,$geolong,$geoflaghtml" >> tmpfile
	done < $inputfile

	# build geodata.htm file
	cp resource/$geodata .
	cat tmpfile | column -s',' -t >> $geodata
	echo '</pre>' >> $geodata

	# create htm file
	cp resource/geo.htm ./$filename
	rm tmpgeo tmpfile 2>/dev/null
	echo
	echo -e "${WHT}See ${GRN}$filename ${WHT}in current directory for results.${NC}"
	f_menu
}

# Menu Function	
f_menu()
{
	echo
	echo -e "${WHT}Please Select:${NC}"
	echo
	echo "1. Input single IP Address"
	echo "2. Input From File"
	echo "q. Quit"
	echo
	echo -n "Enter Selection: "
	read menuopts

	case $menuopts in
		1) f_ipinput;;
		2) f_fileinput;;
		q) exit;;
		*) f_error;;
	esac
}

while true; do
	f_menu;
done